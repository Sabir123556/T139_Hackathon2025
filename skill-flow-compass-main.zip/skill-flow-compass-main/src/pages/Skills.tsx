
import React from 'react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ResourceCard } from '@/components/dashboard/ResourceCard';
import { Progress } from '@/components/ui/progress';
import { skills, userProgress } from '@/data/mockData';
import { formatTime } from '@/utils/helpers';

const Skills: React.FC = () => {
  // Get skills with progress
  const skillsWithProgress = skills
    .map(skill => ({
      skill,
      progress: userProgress.skills[skill.id] || {
        resources: [],
        completionPercentage: 0
      }
    }))
    .sort((a, b) => {
      // Sort by name
      return a.skill.name.localeCompare(b.skill.name);
    });

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Skills & Learning Paths</h1>
        <p className="text-muted-foreground">Explore different skills and their learning resources.</p>
      </div>
      
      <Tabs defaultValue={skillsWithProgress[0].skill.id}>
        <TabsList className="grid grid-cols-2 md:grid-cols-5 h-auto">
          {skillsWithProgress.map(({ skill }) => (
            <TabsTrigger 
              key={skill.id} 
              value={skill.id}
              className="text-sm py-2"
            >
              {skill.name}
            </TabsTrigger>
          ))}
        </TabsList>
        
        {skillsWithProgress.map(({ skill, progress }) => (
          <TabsContent key={skill.id} value={skill.id} className="mt-6">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  <div className={`w-3 h-3 rounded-full bg-skill-${skill.color}`} />
                  <CardTitle>{skill.name}</CardTitle>
                </div>
                <CardDescription>{skill.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Overall Progress</span>
                    <span>{progress.completionPercentage}%</span>
                  </div>
                  <Progress value={progress.completionPercentage} className="h-2" />
                  <p className="text-sm text-muted-foreground">
                    Total duration: {formatTime(skill.totalDuration)}
                  </p>
                </div>
                
                <div>
                  <h3 className="font-medium mb-3">Learning Resources</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {skill.resources.map(resource => {
                      const resourceProgress = progress.resources.find(
                        r => r.resourceId === resource.id
                      );
                      return (
                        <ResourceCard 
                          key={resource.id} 
                          resource={resource} 
                          progress={resourceProgress} 
                        />
                      );
                    })}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
};

export default Skills;
