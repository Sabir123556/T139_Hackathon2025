
import React, { useState } from 'react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { ResourceCard } from '@/components/dashboard/ResourceCard';
import { resources, userProgress } from '@/data/mockData';

const resourceTypes = [
  { value: 'all', label: 'All Types' },
  { value: 'article', label: 'Articles' },
  { value: 'video', label: 'Videos' },
  { value: 'pdf', label: 'PDFs' },
  { value: 'word', label: 'Word Docs' },
  { value: 'link', label: 'Links' },
];

const Resources: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  
  // Flatten all resources that have progress
  const resourcesWithProgress = resources.map(resource => {
    // Find if this resource has any progress across all skills
    const progress = Object.values(userProgress.skills)
      .flatMap(skill => skill.resources)
      .find(p => p.resourceId === resource.id);
    
    return { resource, progress };
  });
  
  // Filter resources based on search and type
  const filterResources = (type: string) => {
    return resourcesWithProgress.filter(({ resource }) => {
      const matchesSearch = resource.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           resource.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesType = type === 'all' || resource.type === type;
      
      return matchesSearch && matchesType;
    });
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Learning Resources</h1>
        <p className="text-muted-foreground">Explore all available learning materials.</p>
      </div>
      
      <div className="w-full max-w-md">
        <Input
          placeholder="Search resources..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full"
        />
      </div>
      
      <Tabs defaultValue="all">
        <TabsList className="grid grid-cols-3 md:grid-cols-6 h-auto">
          {resourceTypes.map((type) => (
            <TabsTrigger 
              key={type.value} 
              value={type.value}
              className="text-sm py-2"
            >
              {type.label}
            </TabsTrigger>
          ))}
        </TabsList>
        
        {resourceTypes.map((type) => (
          <TabsContent key={type.value} value={type.value} className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>{type.label}</CardTitle>
                <CardDescription>
                  {type.value === 'all' 
                    ? 'All learning resources'
                    : `Learning resources in ${type.label.toLowerCase()} format`}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filterResources(type.value).length > 0 ? (
                    filterResources(type.value).map(({ resource, progress }) => (
                      <ResourceCard 
                        key={resource.id} 
                        resource={resource} 
                        progress={progress} 
                      />
                    ))
                  ) : (
                    <div className="col-span-full text-center py-8">
                      <p className="text-muted-foreground">
                        No resources found for your search criteria.
                      </p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
};

export default Resources;
