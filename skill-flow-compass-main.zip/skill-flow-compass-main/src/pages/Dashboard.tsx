
import React from 'react';
import { Book, BookOpen, Clock, ListCheck } from 'lucide-react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { StatsCard } from '@/components/dashboard/StatsCard';
import { SkillProgress } from '@/components/dashboard/SkillProgress';
import { ResourceCard } from '@/components/dashboard/ResourceCard';
import { RecentActivities } from '@/components/dashboard/RecentActivities';
import { skills, userProgress, resources } from '@/data/mockData';
import { calculateTotalTimeSpent, formatTime } from '@/utils/helpers';

const Dashboard: React.FC = () => {
  // Calculate total statistics
  const totalTimeSpent = calculateTotalTimeSpent(userProgress);
  const totalSkills = Object.keys(userProgress.skills).length;
  const completedResources = Object.values(userProgress.skills)
    .flatMap(skill => skill.resources)
    .filter(r => r.completed)
    .length;
  const totalResources = Object.values(userProgress.skills)
    .flatMap(skill => skill.resources)
    .length;
  
  // Get skills with progress
  const skillsWithProgress = skills
    .filter(skill => userProgress.skills[skill.id])
    .map(skill => ({
      skill,
      progress: userProgress.skills[skill.id]
    }))
    .sort((a, b) => {
      // Sort by completion percentage (descending)
      return b.progress.completionPercentage - a.progress.completionPercentage;
    });
  
  // Get resources in progress (not completed)
  const resourcesInProgress = Object.values(userProgress.skills)
    .flatMap(skill => skill.resources)
    .filter(progress => !progress.completed && progress.timeSpent > 0)
    .slice(0, 3)
    .map(progress => {
      const resource = resources.find(r => r.id === progress.resourceId);
      return { resource, progress };
    });

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Learning Dashboard</h1>
        <p className="text-muted-foreground">Track your progress and continue your learning journey.</p>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard 
          title="Total Time Spent" 
          value={formatTime(totalTimeSpent)} 
          icon={<Clock className="h-4 w-4 text-muted-foreground" />}
          description="Total learning time" 
        />
        <StatsCard 
          title="Skills in Progress" 
          value={totalSkills} 
          icon={<Book className="h-4 w-4 text-muted-foreground" />}
          description="Active learning paths" 
        />
        <StatsCard 
          title="Completed Resources" 
          value={`${completedResources}/${totalResources}`} 
          icon={<ListCheck className="h-4 w-4 text-muted-foreground" />}
          description="Learning materials finished" 
        />
        <StatsCard 
          title="Learning Streak" 
          value="5 days" 
          icon={<BookOpen className="h-4 w-4 text-muted-foreground" />}
          description="Keep it up!" 
        />
      </div>
      
      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column */}
        <div className="lg:col-span-2 space-y-6">
          {/* Skills Progress */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Skills Progress</CardTitle>
              <CardDescription>Track your advancement in different skill areas</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {skillsWithProgress.map(({ skill, progress }) => (
                  <SkillProgress key={skill.id} skill={skill} progress={progress} />
                ))}
              </div>
            </CardContent>
          </Card>
          
          {/* Continue Learning */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Continue Learning</CardTitle>
              <CardDescription>Pick up where you left off</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {resourcesInProgress.map(({ resource, progress }, index) => (
                  <ResourceCard key={index} resource={resource!} progress={progress} />
                ))}
                {resourcesInProgress.length === 0 && (
                  <div className="col-span-full text-center py-4">
                    <p className="text-muted-foreground">No resources in progress. Start learning!</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Right Column */}
        <div className="space-y-6">
          {/* Recent Activities */}
          <RecentActivities />
          
          {/* Recommended Resources */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Recommended Resources</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {resources.slice(0, 3).map((resource) => (
                  <ResourceCard key={resource.id} resource={resource} />
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
