
import { Resource, Skill, UserProgress } from "@/types";

export const resources: Resource[] = [
  {
    id: "r1",
    title: "Introduction to Machine Learning",
    type: "article",
    url: "#",
    duration: 15,
    description: "A comprehensive introduction to machine learning concepts."
  },
  {
    id: "r2",
    title: "Advanced Data Structures",
    type: "pdf",
    url: "#",
    duration: 45,
    description: "Learn about complex data structures and their applications."
  },
  {
    id: "r3",
    title: "Web Development Fundamentals",
    type: "video",
    url: "#",
    duration: 60,
    description: "A beginner's guide to HTML, CSS, and JavaScript."
  },
  {
    id: "r4",
    title: "Database Design Principles",
    type: "article",
    url: "#",
    duration: 30,
    description: "Essential principles for designing efficient databases."
  },
  {
    id: "r5",
    title: "Cloud Computing Architecture",
    type: "pdf",
    url: "#",
    duration: 40,
    description: "Overview of cloud architecture and services."
  },
  {
    id: "r6",
    title: "Network Security Fundamentals",
    type: "video",
    url: "#",
    duration: 75,
    description: "Core concepts in securing computer networks."
  },
  {
    id: "r7",
    title: "Artificial Intelligence Ethics",
    type: "article",
    url: "#",
    duration: 25,
    description: "Ethical considerations in AI development and deployment."
  },
  {
    id: "r8",
    title: "Mobile App Development",
    type: "video",
    url: "#",
    duration: 90,
    description: "Creating responsive applications for mobile devices."
  },
  {
    id: "r9",
    title: "Python Programming",
    type: "pdf",
    url: "#",
    duration: 55,
    description: "Fundamentals of Python programming language."
  },
  {
    id: "r10",
    title: "User Experience Design",
    type: "article",
    url: "#",
    duration: 35,
    description: "Principles of designing user-centered interfaces."
  },
];

export const skills: Skill[] = [
  {
    id: "s1",
    name: "Machine Learning",
    description: "Understanding machine learning algorithms and applications",
    color: "purple",
    resources: [resources[0], resources[6]],
    totalDuration: resources[0].duration + resources[6].duration
  },
  {
    id: "s2",
    name: "Web Development",
    description: "Building responsive and interactive web applications",
    color: "blue",
    resources: [resources[2], resources[7]],
    totalDuration: resources[2].duration + resources[7].duration
  },
  {
    id: "s3",
    name: "Database Management",
    description: "Designing and managing efficient database systems",
    color: "green",
    resources: [resources[3], resources[4]],
    totalDuration: resources[3].duration + resources[4].duration
  },
  {
    id: "s4",
    name: "Computer Science",
    description: "Core computer science concepts and algorithms",
    color: "orange",
    resources: [resources[1], resources[8]],
    totalDuration: resources[1].duration + resources[8].duration
  },
  {
    id: "s5",
    name: "Cybersecurity",
    description: "Protecting systems and networks from digital attacks",
    color: "red",
    resources: [resources[5], resources[9]],
    totalDuration: resources[5].duration + resources[9].duration
  }
];

export const userProgress: UserProgress = {
  userId: "user1",
  skills: {
    "s1": {
      resources: [
        {
          resourceId: "r1",
          completed: true,
          timeSpent: 18,
          lastAccessed: "2023-04-01T10:30:00Z"
        },
        {
          resourceId: "r7",
          completed: false,
          timeSpent: 10,
          lastAccessed: "2023-04-02T14:45:00Z"
        }
      ],
      completionPercentage: 50
    },
    "s2": {
      resources: [
        {
          resourceId: "r3",
          completed: true,
          timeSpent: 65,
          lastAccessed: "2023-03-28T09:15:00Z"
        },
        {
          resourceId: "r8",
          completed: false,
          timeSpent: 30,
          lastAccessed: "2023-04-03T16:20:00Z"
        }
      ],
      completionPercentage: 50
    },
    "s3": {
      resources: [
        {
          resourceId: "r4",
          completed: false,
          timeSpent: 15,
          lastAccessed: "2023-04-04T11:10:00Z"
        },
        {
          resourceId: "r5",
          completed: false,
          timeSpent: 0,
          lastAccessed: ""
        }
      ],
      completionPercentage: 0
    },
    "s4": {
      resources: [
        {
          resourceId: "r2",
          completed: true,
          timeSpent: 50,
          lastAccessed: "2023-03-25T13:40:00Z"
        },
        {
          resourceId: "r9",
          completed: true,
          timeSpent: 60,
          lastAccessed: "2023-03-30T15:35:00Z"
        }
      ],
      completionPercentage: 100
    },
    "s5": {
      resources: [
        {
          resourceId: "r6",
          completed: false,
          timeSpent: 40,
          lastAccessed: "2023-04-05T10:05:00Z"
        },
        {
          resourceId: "r10",
          completed: true,
          timeSpent: 35,
          lastAccessed: "2023-04-01T08:50:00Z"
        }
      ],
      completionPercentage: 50
    }
  }
};
