
export interface Resource {
  id: string;
  title: string;
  type: 'article' | 'video' | 'pdf' | 'word' | 'link';
  url: string;
  duration: number; // in minutes
  description: string;
}

export interface Skill {
  id: string;
  name: string;
  description: string;
  color: 'blue' | 'purple' | 'green' | 'orange' | 'red';
  resources: Resource[];
  totalDuration: number;
}

export interface Progress {
  resourceId: string;
  completed: boolean;
  timeSpent: number; // in minutes
  lastAccessed: string;
}

export interface UserProgress {
  userId: string;
  skills: {
    [skillId: string]: {
      resources: Progress[];
      completionPercentage: number;
    }
  }
}

// Add types for the instructor page form
export interface ResourceForm {
  id?: string;
  title: string;
  type: 'article' | 'video' | 'pdf' | 'word' | 'link';
  url: string;
  duration: number; // in minutes
  description: string;
}

export interface SkillForm {
  id?: string;
  name: string;
  description: string;
  color: 'blue' | 'purple' | 'green' | 'orange' | 'red';
}
