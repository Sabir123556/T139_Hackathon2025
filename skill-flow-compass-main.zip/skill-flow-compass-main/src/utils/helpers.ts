
import { Resource, Skill, UserProgress } from "@/types";

export const formatTime = (minutes: number): string => {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  
  if (hours === 0) {
    return `${mins} min`;
  }
  
  return `${hours}h ${mins}m`;
};

export const calculateTotalTimeSpent = (userProgress: UserProgress): number => {
  let totalTime = 0;
  
  Object.values(userProgress.skills).forEach(skill => {
    skill.resources.forEach(resource => {
      totalTime += resource.timeSpent;
    });
  });
  
  return totalTime;
};

export const calculateCompletionPercentage = (
  skill: Skill, 
  userProgress: UserProgress
): number => {
  const skillProgress = userProgress.skills[skill.id];
  
  if (!skillProgress) {
    return 0;
  }
  
  const totalResources = skill.resources.length;
  const completedResources = skillProgress.resources.filter(r => r.completed).length;
  
  return Math.round((completedResources / totalResources) * 100);
};

export const getResourceById = (resourceId: string, resources: Resource[]): Resource | undefined => {
  return resources.find(resource => resource.id === resourceId);
};

export const getIconForResourceType = (type: Resource['type']): string => {
  switch (type) {
    case 'article':
      return '📄';
    case 'video':
      return '🎬';
    case 'pdf':
      return '📑';
    case 'word':
      return '📝';
    case 'link':
      return '🔗';
    default:
      return '📚';
  }
};
