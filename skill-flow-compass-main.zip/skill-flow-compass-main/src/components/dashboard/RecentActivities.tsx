
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { resources, userProgress } from '@/data/mockData';
import { getResourceById } from '@/utils/helpers';

export const RecentActivities: React.FC = () => {
  // Get all resources with progress, sorted by lastAccessed
  const activities = Object.entries(userProgress.skills)
    .flatMap(([skillId, skill]) => 
      skill.resources
        .filter(progress => progress.lastAccessed)
        .map(progress => {
          const resource = getResourceById(progress.resourceId, resources);
          return {
            skillId,
            resource,
            progress,
          };
        })
    )
    .filter(activity => activity.resource)
    .sort((a, b) => 
      new Date(b.progress.lastAccessed).getTime() - 
      new Date(a.progress.lastAccessed).getTime()
    )
    .slice(0, 5);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Recent Activities</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {activities.length > 0 ? (
            activities.map((activity, index) => (
              <div key={index} className="flex justify-between items-center pb-2 border-b last:border-0">
                <div>
                  <h4 className="font-medium text-sm">{activity.resource?.title}</h4>
                  <p className="text-xs text-muted-foreground">
                    {activity.progress.completed ? 'Completed' : 'In progress'} • 
                    {activity.progress.timeSpent} min spent
                  </p>
                </div>
                <p className="text-xs text-muted-foreground">
                  {new Date(activity.progress.lastAccessed).toLocaleDateString()}
                </p>
              </div>
            ))
          ) : (
            <p className="text-sm text-muted-foreground">No recent activities</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
