
import React from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Resource, Progress as ResourceProgress } from '@/types';
import { formatTime, getIconForResourceType } from '@/utils/helpers';

interface ResourceCardProps {
  resource: Resource;
  progress?: ResourceProgress;
}

export const ResourceCard: React.FC<ResourceCardProps> = ({ resource, progress }) => {
  const isStarted = progress && progress.timeSpent > 0;
  const isCompleted = progress && progress.completed;
  
  const progressPercentage = isStarted 
    ? Math.min(Math.round((progress.timeSpent / resource.duration) * 100), 100)
    : 0;
  
  return (
    <Card className="h-full flex flex-col hover:shadow-md transition-shadow">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="text-2xl">{getIconForResourceType(resource.type)}</div>
          <div className="text-xs px-2 py-1 rounded-full bg-secondary">
            {formatTime(resource.duration)}
          </div>
        </div>
        <CardTitle className="text-base mt-2">{resource.title}</CardTitle>
        <CardDescription className="text-xs line-clamp-2">
          {resource.description}
        </CardDescription>
      </CardHeader>
      <CardContent className="flex-grow">
        {isStarted && (
          <div className="space-y-1">
            <div className="flex justify-between text-xs">
              <span>{isCompleted ? 'Completed' : 'In progress'}</span>
              <span>{progressPercentage}%</span>
            </div>
            <Progress value={progressPercentage} className="h-1.5" />
            {!isCompleted && (
              <p className="text-xs text-muted-foreground mt-1">
                Time spent: {formatTime(progress.timeSpent)}
              </p>
            )}
          </div>
        )}
      </CardContent>
      <CardFooter>
        <Button
          variant={isCompleted ? "secondary" : "default"}
          className="w-full text-sm"
          asChild
        >
          <a href={resource.url} target="_blank" rel="noopener noreferrer">
            {isCompleted ? "Review Again" : isStarted ? "Continue" : "Start Learning"}
          </a>
        </Button>
      </CardFooter>
    </Card>
  );
};
