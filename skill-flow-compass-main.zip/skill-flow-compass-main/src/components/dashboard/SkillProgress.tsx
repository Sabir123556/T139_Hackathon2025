
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Skill, UserProgress } from '@/types';
import { formatTime } from '@/utils/helpers';

interface SkillProgressProps {
  skill: Skill;
  progress: UserProgress['skills'][string];
}

export const SkillProgress: React.FC<SkillProgressProps> = ({ skill, progress }) => {
  // Calculate total time spent on this skill
  const totalTimeSpent = progress.resources.reduce((acc, resource) => acc + resource.timeSpent, 0);
  
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base font-medium">{skill.name}</CardTitle>
          <div className={`w-3 h-3 rounded-full bg-skill-${skill.color}`} />
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <div className="flex justify-between text-sm mb-1">
            <span>Progress</span>
            <span>{progress.completionPercentage}%</span>
          </div>
          <Progress value={progress.completionPercentage} className="h-2" />
          <div className="flex justify-between text-xs text-muted-foreground pt-1">
            <span>Time spent: {formatTime(totalTimeSpent)}</span>
            <span>Total: {formatTime(skill.totalDuration)}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
